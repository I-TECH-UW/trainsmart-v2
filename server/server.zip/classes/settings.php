<?php

class Settings {
    protected static $config;

    public static function getSettings() {
        return [
            'settings' => [
                'displayErrorDetails' => true, // set to true in production
                'addContentLengthHeader' => false,
                "determineRouteBeforeAppMiddleware" => true, // required for the cors middleware to work
                  'db' =>[
                        'host'=> 'localhost',
                        'user'=> 'root',
                        'password'=> 'tr@1nsm@rt',
                        'dbname'=> 'trainsmart',
                    ]  
                
            ],
        ];
    }

    public static function getEmails() {
        return [
            'admin' => 'luchacha.s@gmail.com', //Mandatory
            'training' => '',
            'certificates' => '',
        ];
    }

}

