<?php

class UserController {
    public function __construct() {}

    public function getUser($request, $response, $args) {
        //var_dump($request->headers->);
        //if($request->hasHeader('HTTP_AUTHORIZATION')) {
            //var_export($request->getHeaderLine('HTTP_AUTHORIZATION'));
            //echo $_SERVER["HTTP_AUTHORIZATION"];
            //echo apache_request_headers()["Authorization"];
        //}
        $resp = null;
        $obj = new DataObj();
        DataUtility::Init_HashTable();
        DataUtility::AddParameters("id",$args['id'],DataType::INT);
        $data = $obj->ReturnObject($resp, DataUtility::Params(),'pr_user_getUser', ObjectEnum::DataRow);
        
        header('content-type: application/json; charset=utf-8');
        echo json_encode($data); 
    }
}