/** $ composer require setasign/fpdf:1.8.1 
 * 
 * Install latest version using composer.
 * $ composer require tuupola/slim-jwt-auth
 * If using Apache add the following to the .htaccess file. Otherwise PHP wont have access to Authorization: Bearer header.
 * RewriteRule .* - [env=HTTP_AUTHORIZATION:%{HTTP:Authorization}]
 * 
*/