<?php
class Utility{
	public function Encrypt($param){
		return $param;
	}
	public function Decrypt($param){
		return $param;
	}
	
}