<?php
phpinfo();
/*
$cols [] = array('id' => 1,'name' => 'id');
$cols [] = array('id' => 2,'name' => 'pepfar_category_phrase');
$cols [] = array('id' => 3,'name' => 'c.duration_days');

$previewid = 2; 
$preview = 1;
foreach($cols as $item) {
    if($preview && $previewid !== 0 && $item['id'] !== $previewid)
        continue;
    echo $item['id'];
    if($preview) break;
}*/
?>
